// API Types based on backend models
export interface Tenant {
  id: string;
  email: string;
  first_name: string;
  last_name: string;
  phone?: string;
  avatar?: string;
  plan: 'free' | 'pro' | 'enterprise';
  status: 'active' | 'pending' | 'suspended' | 'unpaid';
  email_verified: boolean;
}

export interface Store {
  id: string;
  tenant_id: string;
  name: string;
  slug: string;
  email?: string;
  phone?: string;
  address?: string;
  logo?: string;
  currency: string;
  timezone: string;
  language: string;
  theme_primary_color: string;
  theme_secondary_color: string;
  theme_mode: 'light' | 'dark' | 'auto';
  theme_font_family: string;
  storefront_layout_draft: string;
  storefront_layout_published: string;
  theme_version: number;
  tax_number?: string;
  maintenance_message?: string;
  status: 'active' | 'inactive' | 'suspended';
}

export type StorefrontSectionType =
  | 'hero'
  | 'featured_products'
  | 'categories_grid'
  | 'newsletter'
  | 'footer';

export interface StorefrontSection {
  id: string;
  type: StorefrontSectionType;
  enabled: boolean;
  title?: string;
  subtitle?: string;
  cta_label?: string;
  cta_href?: string;
}

export interface Product {
  id: string;
  store_id: string;
  title: string;
  description?: string;
  slug: string;
  status: 'draft' | 'published' | 'archived';
  visibility: 'public' | 'private';
  price: number;
  sale_price?: number;
  sale_start?: string;
  sale_end?: string;
  currency: string;
  sku?: string;
  track_stock: boolean;
  stock: number;
  low_stock_threshold?: number;
  weight?: number;
  dimensions?: string;
  brand?: string;
  tax_class?: string;
  meta_title?: string;
  meta_description?: string;
  canonical_url?: string;
  noindex?: boolean;
  category_id?: string;
  published_at?: string;
  created_at: string;
  updated_at: string;
  category?: Category;
  collections?: Collection[];
  tags?: Tag[];
}

export type ProductRelationType = 'upsell' | 'cross_sell';

export interface ProductRelation {
  id?: string;
  source_product_id?: string;
  related_product_id: string;
  relation_type: ProductRelationType;
  position: number;
  related_product?: Product;
}

export interface ProductRelationsResponse {
  upsell_products?: ProductRelation[];
  cross_sell_products?: ProductRelation[];
}

export interface Category {
  id: string;
  store_id: string;
  name: string;
  slug: string;
  description?: string;
  meta_title?: string;
  meta_description?: string;
  canonical_url?: string;
  noindex?: boolean;
  image_url?: string;
  visibility: 'public' | 'private';
  parent_id?: string;
  created_at: string;
  updated_at: string;
  children?: Category[];
}

export interface Collection {
  id: string;
  store_id: string;
  name: string;
  slug: string;
  type: 'manual' | 'automatic';
  rule?: string;
  description?: string;
  meta_title?: string;
  meta_description?: string;
  canonical_url?: string;
  noindex?: boolean;
  image_url?: string;
  created_at: string;
  updated_at: string;
}

export interface CollectionWithProductsResponse extends Collection {
  products: Product[];
  total: number;
  page: number;
  limit: number;
  pages: number;
}

export interface CollectionRule {
  column: string;
  relation: string;
  condition: string;
}

export interface Tag {
  id: string;
  store_id: string;
  name: string;
  slug: string;
  color?: string;
  created_at: string;
  updated_at: string;
}

export interface ProductImage {
  id: string;
  product_id: string;
  url: string;
  url_thumbnail: string;
  url_medium: string;
  url_large: string;
  alt_text?: string;
  caption?: string;
  position: number;
  file_size: number;
  file_type: string;
  created_at: string;
  updated_at: string;
}

// API Request/Response types
export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  token?: string;
  tenant: Tenant;
}

export interface CreateTenantRequest {
  email: string;
  password: string;
  first_name: string;
  last_name: string;
  phone?: string;
  plan: 'free' | 'pro' | 'enterprise';
}

export interface CreateStoreRequest {
  name: string;
  slug: string;
  email?: string;
  phone?: string;
  address?: string;
  logo?: string;
  currency: string;
  timezone: string;
  language: string;
  theme_primary_color?: string;
  theme_secondary_color?: string;
  theme_mode?: 'light' | 'dark' | 'auto';
  theme_font_family?: string;
  storefront_layout_draft?: string;
  tax_number?: string;
  maintenance_message?: string;
}

export interface UpdateStoreRequest {
  name?: string;
  email?: string;
  phone?: string;
  address?: string;
  logo?: string;
  currency?: string;
  timezone?: string;
  language?: string;
  theme_primary_color?: string;
  theme_secondary_color?: string;
  theme_mode?: 'light' | 'dark' | 'auto';
  theme_font_family?: string;
  storefront_layout_draft?: string;
  tax_number?: string;
  maintenance_message?: string;
  status?: 'active' | 'suspended' | 'inactive';
}

export interface UpdateStoreStatusRequest {
  status: 'active' | 'inactive';
}

export interface CreateProductRequest {
  title: string;
  description?: string;
  slug?: string;
  status: 'draft' | 'published' | 'archived';
  visibility: 'public' | 'private';
  price: number;
  sale_price?: number;
  sale_start?: string;
  sale_end?: string;
  currency: string;
  sku?: string;
  track_stock: boolean;
  stock: number;
  low_stock_threshold?: number;
  weight?: number;
  dimensions?: string;
  brand?: string;
  tax_class?: string;
  category_id?: string;
  published_at?: string;
}

export interface ReplaceProductRelationsRequest {
  relations: Array<{
    related_product_id: string;
    relation_type: ProductRelationType;
    position: number;
  }>;
}

export interface CloneProductRequest {
  source_product_id: string;
  title: string;
  sku_suffix?: string;
  include_images: boolean;
}

export interface CloneProductResponse {
  cloned_product: Product & {
    images?: ProductImage[];
  };
  message: string;
}

export interface CreateProductImageRequest {
  file: File;
  alt_text?: string;
  caption?: string;
  position?: number;
}

export interface CreateTagRequest {
  name: string;
  slug: string;
  color?: string;
}

export interface CreateCategoryRequest {
  name: string;
  slug?: string;
  description?: string;
  visibility: 'public' | 'private';
  parent_id?: string;
}

export interface CreateCollectionRequest {
  name: string;
  slug?: string;
  type: 'manual' | 'automatic';
  rule?: string;
}

// Generic API Response
export interface ApiResponse<T> {
  data?: T;
  error?: string;
  message?: string;
}

// Pagination
export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  total_pages: number;
}

// Query parameters
export interface PaginationParams {
  page?: number;
  limit?: number;
}

export interface ProductFilters extends PaginationParams {
  search?: string;
  category_id?: string;
  collection_id?: string;
  tag_id?: string;
  status?: string;
  visibility?: string;
  min_price?: number;
  max_price?: number;
  in_stock?: boolean;
  sort_by?: 'newest' | 'oldest' | 'price_asc' | 'price_desc';
}

// ── Admin Customer Types ────────────────────────────────────────────────────

export interface AdminCustomer {
  id: string;
  email: string;
  first_name: string;
  last_name: string;
  phone?: string | null;
  avatar?: string | null;
  status: 'active' | 'pending' | 'suspended';
  email_verified: boolean;
  two_factor_enabled: boolean;
  accepts_marketing: boolean;
  created_at: string;
}

export interface AdminCustomerAddress {
  id: string;
  customer_id: string;
  store_id: string;
  label: string;
  first_name: string;
  last_name: string;
  company?: string | null;
  address1: string;
  address2?: string | null;
  city: string;
  state?: string | null;
  postal_code: string;
  country: string;
  phone?: string | null;
  is_default: boolean;
  created_at: string;
  updated_at: string;
}

export interface CustomerGroup {
  id: string;
  name: string;
  description?: string | null;
  discount: number;
  member_count: number;
  created_at: string;
}

export type PageType = 'home' | 'promo' | 'blog' | 'info'

export interface StorefrontPage {
  id: string
  store_id: string
  type: PageType
  title: string
  slug: string
  layout_draft: string
  layout_published: string
  status: 'draft' | 'published'
  meta_title?: string
  meta_description?: string
  created_at: string
  updated_at: string
}

export interface CreatePageRequest {
  type: PageType
  title: string
  slug: string
}

export interface UpdatePageRequest {
  title?: string
  layout_draft?: string
  status?: 'draft' | 'published'
  meta_title?: string
  meta_description?: string
}

// ── RBAC Permissions ─────────────────────────────────────────────────────────

export const ALL_PERMISSIONS = [
  'products:create',
  'products:edit',
  'products:delete',
  'products:publish',
  'products:import_export',
  'categories:manage',
  'collections:manage',
  'tags:manage',
  'customers:view',
  'customers:edit',
  'customers:delete',
  'customers:import_export',
  'store:settings_edit',
  'store:media_upload',
  'store:customization',
  'store:pages',
  'store:publish',
  'team:manage',
] as const;

export type Permission = typeof ALL_PERMISSIONS[number];

export const PERMISSION_GROUPS: Record<string, Permission[]> = {
  Products: ['products:create', 'products:edit', 'products:delete', 'products:publish', 'products:import_export'],
  Categories: ['categories:manage'],
  Collections: ['collections:manage'],
  Tags: ['tags:manage'],
  Customers: ['customers:view', 'customers:edit', 'customers:delete', 'customers:import_export'],
  Store: ['store:settings_edit', 'store:media_upload', 'store:customization', 'store:pages', 'store:publish'],
  Team: ['team:manage'],
};

export interface StoreRole {
  id: string;
  store_id: string;
  name: string;
  description: string;
  permissions: Permission[];
  is_system: boolean;
  member_count: number;
  created_at: string;
  updated_at: string;
}

export interface CreateRoleRequest {
  name: string;
  description?: string;
  permissions: Permission[];
}

export interface UpdateRoleRequest {
  name?: string;
  description?: string;
  permissions?: Permission[];
}

// ── Membership ──────────────────────────────────────────────────────────────

export type MemberRole = 'owner' | 'designer' | 'editor' | 'viewer';
export type InvitationStatus = 'pending' | 'accepted' | 'expired' | 'revoked';

export interface StoreMember {
  id: string;
  store_id: string;
  user_id: string;
  email: string;
  name: string;
  display_name: string;
  phone: string;
  bio: string;
  tenant_id: string;
  role: MemberRole;
  store_role_id?: string;
  store_role?: StoreRole;
  permissions: Permission[];
  created_at: string;
}

export interface StoreInvitation {
  id: string;
  store_id: string;
  email: string;
  role: MemberRole;
  store_role_id?: string;
  store_role?: StoreRole;
  status: InvitationStatus;
  expires_at: string;
  created_at: string;
}

export interface CreateInvitationRequest {
  email: string;
  role: 'designer' | 'editor' | 'viewer';
  store_role_id?: string;
}

export interface UpdateMemberRoleRequest {
  role: 'designer' | 'editor' | 'viewer';
  store_role_id?: string | null;
}

// ── Staff / multi-store ───────────────────────────────────────────────────────

export interface StoreWithRole {
  id: string;
  name: string;
  slug: string;
  logo: string | null;
  role: string;
  currency: string;
  theme_primary_color: string;
  display_name: string;
  store_role_name: string;
  owner_name: string;
  permissions: string[];
}

export interface AcceptInvitationWithProfileRequest {
  display_name: string;
  phone: string;
  bio: string;
}